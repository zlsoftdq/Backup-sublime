[![GitHub tag](https://img.shields.io/github/tag/equinusocio/material-theme-white-panels.svg)](https://github.com/equinusocio/material-theme-white-panels)
[![GitHub tag](https://img.shields.io/github/release/equinusocio/material-theme-white-panels.svg?style=flat-square)](https://github.com/equinusocio/material-theme-white-panels/releases)
[![Downloads](https://img.shields.io/packagecontrol/dt/Material%20Theme%20-%20White%20Panels.svg?colorB=80d4cd&style=flat-square)](https://packagecontrol.io/packages/Material%20Theme%20-%20White%20Panels)


# Material Theme - White panels and inputs

This addon allow you to enable the white panels and inputs inside Material Design Theme.


For more info see check the [official Material Theme repository](https://github.com/equinusocio/material-theme)
