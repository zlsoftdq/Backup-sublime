
/* @TOOLTIP
 * Tooltip setting and behavioring
========================================================================= */

  {
    "class": "tool_tip_control",
    "layer0.tint": [0, 0, 0]
  },

  {
    "class": "tool_tip_label_control",
    "color": [255, 255, 255, 150]
  },